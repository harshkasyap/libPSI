#pragma once




#include <vector> 
#include "cryptoTools/Common/Defines.h"
#include "util.h"


void DktSend(LaunchParams& params);
void DktRecv(LaunchParams& params);

