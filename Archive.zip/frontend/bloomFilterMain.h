#pragma once


#include "util.h"

void bfSend(LaunchParams& params);
void bfRecv(LaunchParams& params);
