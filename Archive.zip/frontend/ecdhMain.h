#pragma once




#include <vector> 
#include "cryptoTools/Common/Defines.h"
#include "util.h"


void EcdhSend(LaunchParams& params);
void EcdhRecv(LaunchParams& params);

