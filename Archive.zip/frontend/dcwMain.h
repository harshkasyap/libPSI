#pragma once





#include "util.h"


#include <vector> 
#include "cryptoTools/Common/Defines.h"



void DcwRSend(LaunchParams&);
void DcwRRecv(LaunchParams&);

