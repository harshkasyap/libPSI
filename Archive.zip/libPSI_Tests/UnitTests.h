#pragma once

#include <cryptoTools/Common/TestCollection.h>
namespace libPSI_Tests
{
    extern osuCrypto::TestCollection Tests;
}