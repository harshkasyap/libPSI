#pragma once


void BgiPir_keyGen_128_test();

void BgiPir_keyGen_test();
void BgiPir_PIR_test();
void BgiPir_FullDomain_test();
void BgiPir_FullDomain_iterator_test();
void BgiPir_FullDomain_multikey_test();
