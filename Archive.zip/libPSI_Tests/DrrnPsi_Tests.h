#pragma once

void Psi_drrn_SingletonSet_Test_Impl();
void Psi_drrn_FullSet_Test_Impl();
void Psi_drrn_EmptySet_Test_Impl();
