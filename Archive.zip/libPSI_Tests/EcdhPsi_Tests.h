#pragma once

void EcdhPsi_EmptySet_Test_Impl  ();
void EcdhPsi_FullSet_Test_Impl    ();
void EcdhPsi_SingltonSet_Test_Impl();
