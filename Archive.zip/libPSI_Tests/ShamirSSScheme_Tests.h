#pragma once
#ifdef ENABLE_DCW_PSI


void ShamirSSScheme_Test();
#endif