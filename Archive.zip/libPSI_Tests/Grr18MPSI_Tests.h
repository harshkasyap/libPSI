#pragma once

void Grr18_Oos_EmptySet_Test_Impl();
void Grr18_Oos_FullSet_Test_Impl();
void Grr18_Oos_parallel_FullSet_Test_Impl();
void Grr18_Oos_SingltonSet_Test_Impl(); 