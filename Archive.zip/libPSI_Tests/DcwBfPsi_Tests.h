#pragma once

//void DcwBfPsi_EmptySet_Test_Impl();
//void DcwBfPsi_FullSet_Test_Impl();
//void DcwBfPsi_SingltonSet_Test_Impl();
//


void DcwRBfPsi_EmptySet_Test_Impl();
void DcwRBfPsi_FullSet_Test_Impl();
void DcwRBfPsi_SingltonSet_Test_Impl();
