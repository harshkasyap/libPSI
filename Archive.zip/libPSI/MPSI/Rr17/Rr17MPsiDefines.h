#pragma once
#include "cryptoTools/Common/Defines.h"

namespace osuCrypto
{


    static const u64 stepSize(512);
}