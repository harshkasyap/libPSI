# Experimental C++11 version of sparsehash

[![License](https://img.shields.io/badge/License-BSD%203--Clause-blue.svg)](https://opensource.org/licenses/BSD-3-Clause)

| Operating system  | Build Status |
| ------------- | ------------- |
| Linux/Mac  | [![Linux/Mac Build](https://travis-ci.org/sparsehash/sparsehash-c11.svg?branch=master)](https://travis-ci.org/sparsehash/sparsehash-c11)  |
| Windows  | [![Windows Build](https://ci.appveyor.com/api/projects/status/i2eikr5a5d6wf9u8/branch/master?svg=true)](https://ci.appveyor.com/project/Dekken/sparsehash-c11)  |

[Original README](https://github.com/sparsehash/sparsehash-c11/raw/master/README)