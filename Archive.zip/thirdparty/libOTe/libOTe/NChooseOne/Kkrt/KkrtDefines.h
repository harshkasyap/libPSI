#pragma once
// This file and the associated implementation has been placed in the public domain, waiving all copyright. No restrictions are placed on its use. 

#define KKRT_SHA_HASH


//#define NCO_SEND_BLOCK_SIZE 16