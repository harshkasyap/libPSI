#pragma once

#include <cryptoTools/Crypto/Blake2.h>
namespace osuCrypto
{
	using RandomOracle = Blake2;
}