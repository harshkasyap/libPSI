
#include "SocketAdapter.h"

namespace osuCrypto
{

 
}