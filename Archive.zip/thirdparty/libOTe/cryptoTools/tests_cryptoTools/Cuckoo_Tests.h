#pragma once

namespace tests_cryptoTools
{
    void CuckooIndex_many_Test_Impl();
    void CuckooIndex_paramSweep_Test_Impl();
    void CuckooIndex_parallel_Test_Impl();

	//void CuckooIndexVsCuckooHasher();
}