#pragma once

#include <cryptoTools/Common/TestCollection.h>


namespace tests_cryptoTools
{
    extern osuCrypto::TestCollection Tests;
}