#pragma once
// This file and the associated implementation has been placed in the public domain, waiving all copyright. No restrictions are placed on its use.  


namespace tests_libOTe
{
    void Bot_NaorPinkas_Test();
    void Bot_Simplest_Test();
    void Bot_MasnyRindal_Test();
    void Bot_MasnyRindal_Kyber_Test();

    void Bot_McQuoidRR_Moeller_EKE_Test();
    void Bot_McQuoidRR_Moeller_MR_Test();
    void Bot_McQuoidRR_Moeller_F_Test();
    void Bot_McQuoidRR_Moeller_FM_Test();
    void Bot_McQuoidRR_Ristrestto_F_Test();
    void Bot_McQuoidRR_Ristrestto_FM_Test();


    //template<template<typename> class PopfOT, typename DSPopf>
    //void Bot_PopfOT_Test();
}
