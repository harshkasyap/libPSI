#define cKeccakB    1600
#define cKeccakR    1088
