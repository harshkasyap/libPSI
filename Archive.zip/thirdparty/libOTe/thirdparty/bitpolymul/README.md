# Multiplication for Long binary Polynomials.

1. Type make for building bitpolymul-test

2. run run_test.sh for benchmarking polynomial multiplications.


BitPolyMul is the implementation of the APPENDIX of http://arxiv.org/abs/1708.09746 .
