#ifndef KYBER_GENMATRIX
#define KYBER_GENMATRIX

#include "polyvec.h"

void genmatrix(polyvec *a, const unsigned char *seed, int transposed);

#endif
